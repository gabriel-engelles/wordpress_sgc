<footer>
    <p>&copy; <?php echo date('Y'); ?> - Meu Tema WordPress</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>