<?php
/**
 * Plugin Name: Censura de Artigos
 * Plugin URI:
 * Description: Censura palavras proibidas no título e no conteúdo dos artigos, substituindo por "(censurado)".
 * Version: 1.0
 * Author: Gabriel Morais
 * Author URI:
 * License: GPL2
 */

// Função de instalação para criar a tabela no banco de dados
function censura_instalar() {
    global $wpdb;
    $tabela_censura = $wpdb->prefix . 'censura';

    $sql = "CREATE TABLE IF NOT EXISTS $tabela_censura (
        id INT AUTO_INCREMENT PRIMARY KEY,
        palavra VARCHAR(255) NOT NULL UNIQUE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    // Inserir palavras proibidas padrão
    $palavras_proibidas = ['palavra_proibida', 'palavra_feia', 'palavra_ofensiva', 'palavra_inadequada'];

    foreach ($palavras_proibidas as $palavra) {
        $wpdb->insert($tabela_censura, ['palavra' => $palavra]);
    }
}
register_activation_hook(__FILE__, 'censura_instalar');

// Função de desinstalação para remover a tabela do banco de dados
function censura_desinstalar() {
    global $wpdb;
    $tabela_censura = $wpdb->prefix . 'censura';

    $sql = "DROP TABLE IF EXISTS $tabela_censura;";
    $wpdb->query($sql);
}
register_uninstall_hook(__FILE__, 'censura_desinstalar');

// Função para obter a lista de palavras proibidas do banco de dados
function obter_palavras_proibidas() {
    global $wpdb;
    $tabela_censura = $wpdb->prefix . 'censura';

    $resultados = $wpdb->get_col("SELECT palavra FROM $tabela_censura");

    return $resultados ?: [];
}

// Função para censurar palavras no título e no conteúdo
function censurar_texto($texto) {
    $palavras_proibidas = obter_palavras_proibidas();

    foreach ($palavras_proibidas as $palavra) {
        $texto = preg_replace('/\b' . preg_quote($palavra, '/') . '\b/i', '(censurado)', $texto);
    }

    return $texto;
}

// Aplicar censura ao título dos artigos
function censurar_titulo($title) {
    return censurar_texto($title);
}
add_filter('the_title', 'censurar_titulo');

// Aplicar censura ao corpo dos artigos
function censurar_conteudo($content) {
    return censurar_texto($content);
}
add_filter('the_content', 'censurar_conteudo');
