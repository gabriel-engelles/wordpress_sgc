<?php
/**
 * Plugin Name: Limite do Corpo do Artigo
 * Plugin URI:
 * Description: Limita o tamanho do corpo do artigo a 10 palavras e adiciona um sufixo para leitura completa.
 * Version: 1.0
 * Author: a58790
  * License: GPL2
 */

// Hook para modificar o conteúdo do artigo
function limite_corpo_artigo($content) {
    // Verifica se é um post do tipo artigo
    if (is_single()) {
        // Divide o conteúdo em palavras
        $words = explode(' ', $content);
        // Limita as palavras a 10
        if (count($words) > 10) {
            // Adiciona o sufixo no final
            $content = implode(' ', array_slice($words, 0, 10)) . '... para ler mais tem que se identificar';
        }
    }
    return $content;
}

// Adiciona a função ao filtro 'the_content'
add_filter('the_content', 'limite_corpo_artigo');
